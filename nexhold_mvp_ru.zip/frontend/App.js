
import './App.css';

export default function App() {
  return (
    <div className="app">
      <header className="header">
        <h1 className="logo">NEXHOLD</h1>
        <p className="tagline">Следующий уровень гаранта</p>
      </header>

      <div className="card">
        <h3>PUBG Mobile — Буст</h3>
        <p>Тип сделки: Услуга</p>
        <p>Риск: Низкий</p>
        <p>Цена: 3 000 ₽</p>

        <label>
          <input type="checkbox" />
          Я подтверждаю правильность данных аккаунта
        </label>

        <button>Оплатить через СБП</button>
      </div>

      <div className="card warning">
        <h3>Продажа игрового аккаунта</h3>
        <p>⚠️ Повышенный риск</p>

        <label>
          <input type="checkbox" />
          Я принимаю дисклеймер и осознаю риски
        </label>

        <button disabled>Оплата недоступна</button>
      </div>

      <footer className="footer">
        NexHold — информационная платформа и агент по приёму платежей.
        Платформа не является стороной сделки между пользователями.
      </footer>
    </div>
  );
}
