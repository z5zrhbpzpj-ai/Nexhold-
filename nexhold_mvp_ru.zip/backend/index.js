
const express = require('express');
const app = express();
app.use(express.json());

let orders = [];
let proofs = [];

app.post('/orders', (req, res) => {
  const { risk, disclaimerAccepted } = req.body;

  if (risk === 'high' && !disclaimerAccepted) {
    return res.status(400).json({
      error: 'Для данной сделки необходимо принять дисклеймер о повышенных рисках'
    });
  }

  const order = {
    id: orders.length + 1,
    ...req.body,
    status: 'СОЗДАНО'
  };

  orders.push(order);
  res.json(order);
});

app.post('/orders/:id/proof', (req, res) => {
  const { type } = req.body;

  if (!['image', 'video'].includes(type)) {
    return res.status(400).json({
      error: 'Допускаются только фото или видео доказательства'
    });
  }

  proofs.push({ orderId: req.params.id, type });

  const order = orders.find(o => o.id == req.params.id);
  order.status = 'ДОКАЗАТЕЛЬСТВА_ЗАГРУЖЕНЫ';

  res.json({ success: true, message: 'Доказательства успешно загружены' });
});

app.post('/orders/:id/complete', (req, res) => {
  const order = orders.find(o => o.id == req.params.id);

  if (order.status !== 'ДОКАЗАТЕЛЬСТВА_ЗАГРУЖЕНЫ') {
    return res.status(400).json({
      error: 'Сделка не может быть завершена без доказательств'
    });
  }

  order.status = 'СДЕЛКА_ЗАВЕРШЕНА';
  res.json(order);
});

app.listen(3000, () => {
  console.log('NexHold backend запущен на порту 3000');
});
